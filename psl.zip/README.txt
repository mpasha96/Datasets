This zip archive contains data files from Cricsheet in YAML format. This
archive contains 24 Pakistan Super League matches.

The data files contained in this zip file are version 0.9 files, which is the
default version. You can learn about the latest default format at
http://cricsheet.org/format/

You can find the available downloads at http://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
http://cricsheet.org/downloads/psl.zip

The data files contained in this zip archive are listed below. The first
field is the start date of the match (for test matches or other multi-day
matches), or the actual date (for all other types of match). The second is
the type of teams involved, whether 'club', or 'international'. The third is
the type of match, either Test, ODI, ODM, T20, IT20, MDM, or a club
competition code (such as IPL). The 4th field is the gender of the players
involved in the match. The 5th field is the id of the data file, and the
remainder of the line shows the teams involved in the match.

2017-02-09 - club - PSL - male - 1075986 vs Islamabad United
2017-02-10 - club - PSL - male - 1075987 vs Lahore Qalandars
2017-02-10 - club - PSL - male - 1075988 vs Karachi Kings
2017-02-11 - club - PSL - male - 1075989 vs Islamabad United
2017-02-11 - club - PSL - male - 1075990 vs Karachi Kings
2017-02-12 - club - PSL - male - 1075991 vs Lahore Qalandars
2017-02-15 - club - PSL - male - 1075992 vs Islamabad United
2017-02-16 - club - PSL - male - 1075993 vs Karachi Kings
2017-02-17 - club - PSL - male - 1075994 vs Peshawar Zalmi
2017-02-17 - club - PSL - male - 1075995 vs Islamabad United
2017-02-18 - club - PSL - male - 1075996 vs Lahore Qalandars
2017-02-18 - club - PSL - male - 1075997 vs Islamabad United
2017-02-19 - club - PSL - male - 1075998 vs Karachi Kings
2017-02-20 - club - PSL - male - 1075999 vs Islamabad United
2017-02-23 - club - PSL - male - 1076000 vs Karachi Kings
2017-02-24 - club - PSL - male - 1076001 vs Lahore Qalandars
2017-02-24 - club - PSL - male - 1076002 vs Islamabad United
2017-02-25 - club - PSL - male - 1076003 vs Karachi Kings
2017-02-25 - club - PSL - male - 1076004 vs Peshawar Zalmi
2017-02-26 - club - PSL - male - 1076005 vs Islamabad United
2017-02-28 - club - PSL - male - 1076006 vs Peshawar Zalmi
2017-03-01 - club - PSL - male - 1076007 vs Islamabad United
2017-03-03 - club - PSL - male - 1076008 vs Karachi Kings
2017-03-05 - club - PSL - male - 1076009 vs Peshawar Zalmi